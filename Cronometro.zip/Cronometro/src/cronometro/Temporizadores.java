
package cronometro;

import java.time.LocalTime;
import java.util.Date;
import java.util.TimerTask;


public class Temporizadores extends TimerTask {
       @Override
        public void run(){
           ImprimirDatos();
        }
   public void ImprimirDatos(){
                  System.out.println("Alarma  "+new Date());

   }
   public void HoraActual (){
       LocalTime horaActual= LocalTime.now();
        System.out.println("La Hora Actual es: "+horaActual);
   }

 
           
}
