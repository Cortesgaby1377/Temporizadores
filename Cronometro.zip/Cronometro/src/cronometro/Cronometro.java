
package cronometro;

import java.time.LocalTime;
import java.util.Date;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;


public class Cronometro {

   
    public static void main(String[] args) {
     int segundos1,segundos2,minutos1,minutos2,horas1,horas2;
        Temporizadores objeto1= new Temporizadores();
         objeto1.HoraActual();
        Timer timer =new Timer();
   Temporizadores tarea=new Temporizadores();
   Scanner scan=new Scanner(System.in);
   
   
   
   
   System.out.print("Digite el tiempo para iniciar la alarma en segundos: ");
   int a=scan.nextInt();
   System.out.print("Digite el intervalo de tiempo entre cada alarma en segundos : ");
   int b=scan.nextInt();
           segundos1=a*1000;
           segundos2=b*1000;
            timer.schedule(tarea,segundos1,segundos2);  
           
          
 }
    
}
